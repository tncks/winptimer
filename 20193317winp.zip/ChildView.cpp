﻿
// ChildView.cpp: CChildView 클래스의 구현
//

#include "pch.h"
#include "framework.h"
#include "20193317노수찬_1027.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	m_color = RGB(255, 0, 0);
	m_nX = 100;
	m_nY = 100;
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_COMMAND(32771, &CChildView::OnColorRed)
	ON_COMMAND(32772, &CChildView::OnColorGreen)
	ON_COMMAND(32773, &CChildView::OnColorBlue)
	ON_UPDATE_COMMAND_UI(32771, &CChildView::OnUpdateColorRed)
	ON_UPDATE_COMMAND_UI(32772, &CChildView::OnUpdateColorGreen)
	ON_UPDATE_COMMAND_UI(32773, &CChildView::OnUpdateColorBlue)
	ON_WM_CONTEXTMENU()
	ON_WM_TIMER()
	ON_WM_CREATE()
	ON_WM_DESTROY()
END_MESSAGE_MAP()



BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs)
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS,
		::LoadCursor(nullptr, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1), nullptr);

	return TRUE;
}

void CChildView::OnPaint()
{
	
	CPaintDC dc(this);
	CBrush mybrush;

	mybrush.CreateSolidBrush(m_color);

	dc.SelectObject(&mybrush);
	
	dc.Ellipse(m_nX, m_nY, m_nX+50, m_nY+50);
	
	
}


void CChildView::OnColorRed()
{
	m_color = RGB(255, 0, 0);
	Invalidate();
}


void CChildView::OnColorGreen()
{
	m_color = RGB(0, 255, 0);
	Invalidate();
}


void CChildView::OnColorBlue()
{
	m_color = RGB(0, 0, 255);
	Invalidate();
}


void CChildView::OnUpdateColorRed(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_color == RGB(255, 0, 0));
}


void CChildView::OnUpdateColorGreen(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_color == RGB(0, 255, 0));
}


void CChildView::OnUpdateColorBlue(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_color == RGB(0, 0, 255));
}


void CChildView::OnContextMenu(CWnd* /*pWnd*/, CPoint point)
{
	CMenu menu;
	menu.LoadMenu(IDR_MAINFRAME);
	CMenu* pMenu = menu.GetSubMenu(4);
	pMenu->TrackPopupMenu(
		TPM_LEFTALIGN | TPM_RIGHTBUTTON,
		point.x, point.y, AfxGetMainWnd());
}



int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	SetTimer(1, 10, NULL);

	return 0;

	//m_nY = 300;
}


void CChildView::OnDestroy()
{
	// TODO: 여기에 구현 코드 추가.
	KillTimer(1);
}

void CChildView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	switch (nIDEvent) {
	case 1:
		m_nY += 1;
		break;
	}
	

	Invalidate();
}